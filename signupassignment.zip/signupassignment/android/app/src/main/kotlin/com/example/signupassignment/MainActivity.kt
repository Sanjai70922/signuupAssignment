package com.example.signupassignment

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
