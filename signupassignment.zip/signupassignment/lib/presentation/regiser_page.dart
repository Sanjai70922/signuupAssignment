// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:flutter_pw_validator/flutter_pw_validator.dart';

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  //textcontrollers
  final _emailcontroller = TextEditingController();
  final _passwordcontroller = TextEditingController();
  final _confirmPasswordcontroller = TextEditingController();
  bool success = false;
  bool _passwordVisible = true;

  @override
  void dispose() {
    _emailcontroller.dispose();
    _passwordcontroller.dispose();
    _confirmPasswordcontroller.dispose();
    super.dispose();
  }

  signUp() {
    if (passwordComfirmed()) {
      //create user
      if (_emailcontroller.text != "" &&
          _passwordcontroller.text != "" &&
          _confirmPasswordcontroller.text != "") {
        ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("Successfully Registered")));
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text("Password and confirm password is not matched")));
    }
  }

  bool passwordComfirmed() {
    if (_passwordcontroller.text.trim() ==
        _confirmPasswordcontroller.text.trim()) {
      return true;
    } else {
      return false;
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusManager.instance.primaryFocus?.unfocus(),
      child: Scaffold(
        backgroundColor: Colors.blueGrey[700],
        appBar: AppBar(
          title: Padding(
              padding: EdgeInsets.all(10.0),
              child: Text(
                'Back',
                style: TextStyle(fontSize: 20.0, color: Colors.orange[100]),
              )),
          backgroundColor: Colors.blueGrey[700],
          elevation: 0,
        ),
        body: SafeArea(
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: 60.0,
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 40.0, bottom: 10.0),
                  child: Text('Email',
                      style: TextStyle(fontSize: 15.0, color: Colors.white)),
                ),
                //email textfield
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 25.0),
                  child: Container(
                    decoration: BoxDecoration(
                        color: Colors.blueGrey[400],
                        border: Border.all(color: Colors.blueGrey),
                        borderRadius: BorderRadius.circular(5.0)),
                    child: Padding(
                      padding: EdgeInsets.only(left: 20.0),
                      child: TextFormField(
                        controller: _emailcontroller,
                        decoration: InputDecoration(
                          border: InputBorder.none,
                          hintText: 'example@mail.com',
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: 30.0,
                ),
                //password field
                Padding(
                  padding: const EdgeInsets.only(left: 40.0, bottom: 10.0),
                  child: Text('New Password',
                      style: TextStyle(fontSize: 15.0, color: Colors.white)),
                ),

                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 25.0),
                  child: Container(
                    decoration: BoxDecoration(
                        color: Colors.blueGrey[400],
                        border: Border.all(color: Colors.blueGrey),
                        borderRadius: BorderRadius.circular(12.0)),
                    child: Padding(
                      padding: EdgeInsets.only(left: 20.0),
                      child: TextFormField(
                        controller: _passwordcontroller,
                        obscureText: _passwordVisible,
                        decoration: InputDecoration(
                          border: InputBorder.none,
                          hintText: 'Choose a Secure Password',
                          suffixIcon: IconButton(
                            color: Colors.grey[700],
                            icon: Icon(_passwordVisible
                                ? Icons.visibility_off
                                : Icons.visibility),
                            iconSize: 24.0,
                            onPressed: () {
                              setState(() {
                                _passwordVisible = !_passwordVisible;
                              });
                            },
                          ),
                        ),
                        onChanged: ((value) {}),
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: 30.0,
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 40.0, bottom: 10.0),
                  child: Text('Re-enter New Password',
                      style: TextStyle(fontSize: 15.0, color: Colors.white)),
                ),

                // confirm passwordfield
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 25.0),
                  child: Container(
                    decoration: BoxDecoration(
                        color: Colors.blueGrey[400],
                        border: Border.all(color: Colors.blueGrey),
                        borderRadius: BorderRadius.circular(12.0)),
                    child: Padding(
                      padding: EdgeInsets.only(left: 20.0),
                      child: TextFormField(
                        controller: _confirmPasswordcontroller,
                        obscureText: _passwordVisible,
                        decoration: InputDecoration(
                          border: InputBorder.none,
                          hintText: 'Choose a Secure Password',
                          suffixIcon: IconButton(
                            color: Colors.grey[700],
                            icon: Icon(_passwordVisible
                                ? Icons.visibility_off
                                : Icons.visibility),
                            iconSize: 24.0,
                            onPressed: () {
                              setState(() {
                                _passwordVisible = !_passwordVisible;
                              });
                            },
                          ),
                        ),
                      ),
                    ),
                  ),
                ),

                SizedBox(
                  height: 10.0,
                ),
                //password validator
                Center(
                  child: Padding(
                    padding: EdgeInsets.symmetric(horizontal: 80.0),
                    child: FlutterPwValidator(
                      controller: _passwordcontroller,
                      minLength: 8,
                      uppercaseCharCount: 1,
                      numericCharCount: 1,
                      specialCharCount: 1,
                      normalCharCount: 3,
                      width: 400,
                      height: 150,
                      onSuccess: () {
                        setState(() {
                          success = true;
                        });
                      },
                      onFail: () {
                        setState(() {
                          success = false;
                        });
                        print("NOT MATCHED");
                      },
                    ),
                  ),
                ),
                SizedBox(
                  height: 25.0,
                ),
                //SignIn Button
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 25.0),
                      child: GestureDetector(
                        onTap: signUp,
                        child: Container(
                          padding: EdgeInsets.symmetric(
                              horizontal: 50.0, vertical: 10.0),
                          decoration: BoxDecoration(
                              color: Colors.orange[200],
                              borderRadius: BorderRadius.circular(5.0)),
                          child: Center(
                              child: Text(
                            'Sign Up',
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 18.0),
                          )),
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 25.0,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
